package ui;

public interface IMainMenuUI {
	void run();
}
