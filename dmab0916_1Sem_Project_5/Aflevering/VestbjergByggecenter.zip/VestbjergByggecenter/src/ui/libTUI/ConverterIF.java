package ui.libTUI;

/**
 * Author: Istvan Knoll - text output re-written to Danish by Stefan 
 */
public interface ConverterIF<T> {
	String convertToString(T o);
}
