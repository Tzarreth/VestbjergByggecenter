package model;

public class Supplier {

	private String name;

	public Supplier(String name){
		setName(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
