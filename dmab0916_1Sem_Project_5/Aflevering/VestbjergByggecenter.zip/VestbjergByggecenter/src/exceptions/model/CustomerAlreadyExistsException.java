package exceptions.model;

public class CustomerAlreadyExistsException extends Exception {
	public CustomerAlreadyExistsException(){
		System.out.println("Kunden findes allerede");
	}
}
