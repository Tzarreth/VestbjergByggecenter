package exceptions.model;

public class CustomerDoesNotExistsException extends Exception{
	public CustomerDoesNotExistsException(){
		System.out.println("Kunden eksisterer ikke");
	}

	public CustomerDoesNotExistsException(Exception e) {
		System.out.println("Kunden eksisterer ikke - " + e.getMessage());
	}
}
